resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

ui_page "ui/index.html"

files {
	"ui/index.html",
	"ui/script.js",
	"ui/style.css"
}

max_speed "250"
client_scripts {
	"client.lua",
}
