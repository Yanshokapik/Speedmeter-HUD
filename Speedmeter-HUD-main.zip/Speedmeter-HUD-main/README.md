Ce scripts est prit de la base de Alynia!

Donc je ne proposerai pas de support.

Je partage se scripts pour que vous Arrêtez d'acheter des trucs alors qu'il sont gratuit!

Créateur @wdesgardin
